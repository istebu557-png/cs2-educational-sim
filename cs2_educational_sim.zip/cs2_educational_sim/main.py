"""
CS2 EĞİTSEL SIMÜLATÖR - Mart 2026 Güncel
Sadece OFFLINE BOT MATCH için!
"""
import pygame
import time
from core.cs2_memory import CS2MemoryReader
from core.math_utils import (
    world_to_screen, world_to_radar, calc_angles, smooth_angles, calc_distance
)
from core.models import CS2LocalPlayerPawn, CS2Entity
from ui.radar import CS2RadarWindow

def main():
    print("=" * 70)
    print("🧪 CS2 EĞİTSEL SIMÜLATÖR v1.0 - MART 2026 GÜNCEL")
    print("⚠️  SADECE OFFLINE BOT MATCH / DEMO ÜZERİNDE TEST ET!")
    print("🚫 ÇEVRİM İÇİ = VAC BAN RİSKİ!")
    print("=" * 70)
    
    # CS2 belleği
    mem = CS2MemoryReader()
    
    # Radar penceresi
    radar = CS2RadarWindow(width=900, height=900)
    
    # Ayarlar
    smooth_factor = 12.0
    screen_w, screen_h = 1920, 1080
    
    clock = pygame.time.Clock()
    running = True
    frame_count = 0
    
    print("[*] Radar penceresi açılıyor... Bot'ları radar'da göreceksin!")
    
    while running:
        dt = clock.tick(60) / 1000.0
        frame_count += 1
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
        
        # RAM'den oku
        local = mem.get_local_player_pawn()
        entities = mem.get_entities()
        view_matrix = mem.get_view_matrix()
        
        # Aimbot simülasyonu
        if entities:
            # En yakın düşman
            closest = min(entities, key=lambda e: calc_distance((e.pos[0]-local.pos[0], e.pos[1]-local.pos[1], e.pos[2]-local.pos[2])))
            tgt_pitch, tgt_yaw = calc_angles(local.pos, closest.pos)
            sim_pitch, sim_yaw = smooth_angles(0, 0, tgt_pitch, tgt_yaw, smooth_factor)
            
            if frame_count % 30 == 0:
                print(f"🎯 AIMBOT | Hedef #{closest.id} | Mesafe: {calc_distance((closest.pos[0]-local.pos[0], closest.pos[1]-local.pos[1], closest.pos[2]-local.pos[2])):.0f}u | "
                      f"Yaw: {sim_yaw:.1f}° Pitch: {sim_pitch:.1f}°")
        
        # W2S (ESP koordinatları)
        esp_points = []
        for ent in entities:
            w2s = world_to_screen(ent.pos, view_matrix, screen_w, screen_h)
            if w2s:
                esp_points.append((w2s, ent))
        
        # Radar çiz
        radar.draw_radar(local, entities)
        
        # Debug info
        if frame_count % 60 == 0:
            print(f"📊 DEBUG | Local: ({local.pos[0]:.0f}, {local.pos[1]:.0f}, {local.pos[2]:.0f}) | "
                  f"Entities: {len(entities)} | W2S örnek: {esp_points[0][0] if esp_points else 'None'}")
    
    pygame.quit()
    print("[+] Simülasyon kapatıldı. Teşekkürler!")

if __name__ == "__main__":
    main()