import pymem
import pymem.process
import struct
from typing import List, Tuple
from .models import CS2Entity, CS2LocalPlayerPawn, Vec3
from .offsets import CS2Offsets

class CS2MemoryReader:
    def __init__(self):
        self.pm = None
        self.client_base = 0
        self.offsets = CS2Offsets()
        self.connect()

    def connect(self):
        try:
            self.pm = pymem.Pymem("cs2.exe")
            client_module = pymem.process.module_from_name(
                self.pm.process_handle, "client.dll"
            )
            self.client_base = client_module.lpBaseOfDll
            print(f"[+] CS2 client.dll: 0x{self.client_base:X}")
        except Exception as e:
            print(f"[-] CS2 process yok! Bot match aç: {e}")

    def read_vec3(self, address: int) -> Vec3:
        if not self.pm or address == 0:
            return (0.0, 0.0, 0.0)
        try:
            data = self.pm.read_bytes(address, 12)
            return struct.unpack("fff", data)
        except:
            return (0.0, 0.0, 0.0)

    def read_int(self, address: int) -> int:
        if not self.pm or address == 0:
            return 0
        try:
            return self.pm.read_int(address)
        except:
            return 0

    def get_view_matrix(self):
        if not self.pm:
            return [1.0] * 16
        try:
            vm_addr = self.client_base + self.offsets.dwViewMatrix
            data = self.pm.read_bytes(vm_addr, 64)
            return list(struct.unpack("16f", data))
        except:
            return [1.0] * 16

    def get_local_player_pawn(self) -> CS2LocalPlayerPawn:
        if not self.pm:
            return CS2LocalPlayerPawn(address=0, pos=(0,0,0), pitch=0, yaw=0)
        try:
            local_ptr = self.pm.read_longlong(self.client_base + self.offsets.dwLocalPlayerPawn)
            if local_ptr == 0:
                return CS2LocalPlayerPawn(address=0, pos=(0,0,0), pitch=0, yaw=0)
            pos = self.read_vec3(local_ptr + self.offsets.m_vOldOrigin)
            return CS2LocalPlayerPawn(address=local_ptr, pos=pos, pitch=0.0, yaw=0.0)
        except:
            return CS2LocalPlayerPawn(address=0, pos=(0,0,0), pitch=0, yaw=0)

    def get_entities(self) -> List[CS2Entity]:
        entities = []
        if not self.pm:
            return entities

        entity_list_addr = self.client_base + self.offsets.dwEntityList
        for i in range(64):
            try:
                list_entry_addr = entity_list_addr + i * 0x8
                list_entry = self.pm.read_longlong(list_entry_addr)
                if list_entry == 0:
                    continue
                
                controller = self.pm.read_longlong(list_entry + 0x78)
                if controller == 0:
                    continue
                
                pawn_ptr = self.pm.read_longlong(controller + 0x78)
                if pawn_ptr == 0:
                    continue

                health = self.read_int(pawn_ptr + self.offsets.m_iHealth)
                team = self.read_int(pawn_ptr + self.offsets.m_iTeamNum)
                pos = self.read_vec3(pawn_ptr + self.offsets.m_vOldOrigin)

                if 0 < health <= 100 and team > 1:
                    entities.append(CS2Entity(
                        address=pawn_ptr,
                        id=i,
                        team=team,
                        health=health,
                        pos=pos,
                    ))
            except:
                continue
        return entities