class CS2Offsets:
    """
    CS2 client.dll offset'leri - Mart 2026 build
    Kaynak: cs2-dumper + forumlar[web:30][web:34]
    """
    # client.dll base pointer'lar:
    dwEntityList = 0x38453928
    dwLocalPlayerPawn = 0x33975136
    dwViewMatrix = 0x36753312

    # Member offset'leri:
    m_iHealth = 0x852
    m_iTeamNum = 0x1011
    m_vOldOrigin = 0x5512
    m_pGameSceneNode = 0x824
    m_modelState = 0x352