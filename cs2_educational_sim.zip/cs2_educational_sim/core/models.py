from dataclasses import dataclass
from typing import Tuple

Vec3 = Tuple[float, float, float]

@dataclass
class CS2Entity:
    """CS2 C_CSPlayerPawn benzeri"""
    address: int
    id: int
    team: int
    health: int
    pos: Vec3

@dataclass
class CS2LocalPlayerPawn:
    """CS2 LocalPlayerPawn"""
    address: int
    pos: Vec3
    pitch: float
    yaw: float