import math
from typing import Tuple, List, Optional
from .models import Vec3

def calc_delta(src: Vec3, dst: Vec3) -> Vec3:
    return (dst[0] - src[0], dst[1] - src[1], dst[2] - src[2])

def calc_distance(delta: Vec3) -> float:
    return math.sqrt(delta[0]**2 + delta[1]**2 + delta[2]**2)

def calc_angles(src: Vec3, dst: Vec3) -> Tuple[float, float]:
    dx, dy, dz = calc_delta(src, dst)
    hyp = math.sqrt(dx**2 + dy**2)
    pitch = -math.degrees(math.atan2(dz, hyp))
    yaw = math.degrees(math.atan2(dy, dx))
    return pitch, yaw

def smooth_angle(current: float, target: float, smooth_factor: float) -> float:
    delta = target - current
    if delta > 180.0:
        delta -= 360.0
    elif delta < -180.0:
        delta += 360.0
    step = delta / smooth_factor
    return current + step

def smooth_angles(cur_pitch: float, cur_yaw: float,
                  tgt_pitch: float, tgt_yaw: float,
                  smooth_factor: float) -> Tuple[float, float]:
    return (
        smooth_angle(cur_pitch, tgt_pitch, smooth_factor),
        smooth_angle(cur_yaw, tgt_yaw, smooth_factor),
    )

def world_to_screen(pos: Vec3,
                    matrix: List[float],
                    screen_width: int,
                    screen_height: int) -> Optional[Tuple[float, float]]:
    x, y, z = pos
    clip_x = x * matrix[0] + y * matrix[1] + z * matrix[2] + matrix[3]
    clip_y = x * matrix[4] + y * matrix[5] + z * matrix[6] + matrix[7]
    clip_z = x * matrix[8] + y * matrix[9] + z * matrix[10] + matrix[11]
    w = x * matrix[12] + y * matrix[13] + z * matrix[14] + matrix[15]

    if w < 0.1:
        return None

    ndc_x = clip_x / w
    ndc_y = clip_y / w
    screen_x = (screen_width / 2) * (1 + ndc_x)
    screen_y = (screen_height / 2) * (1 - ndc_y)
    return screen_x, screen_y

def world_to_radar(local_pos: Vec3,
                   entity_pos: Vec3,
                   scale: float = 0.05) -> Tuple[float, float]:
    dx = (entity_pos[0] - local_pos[0]) * scale
    dy = (entity_pos[1] - local_pos[1]) * scale
    return dx, dy