import pygame
from core.models import CS2LocalPlayerPawn, CS2Entity
from core.math_utils import world_to_radar

class CS2RadarWindow:
    def __init__(self, width: int = 900, height: int = 900):
        pygame.init()
        self.width = width
        self.height = height
        self.screen = pygame.display.set_mode((width, height))
        pygame.display.set_caption("🧪 CS2 Radar - Educational")
        self.clock = pygame.time.Clock()
        self.running = True
        self.font = pygame.font.Font(None, 24)

    def draw_radar(self, local: CS2LocalPlayerPawn, entities: list[CS2Entity]):
        self.screen.fill((10, 10, 20))
        center_x = self.width // 2
        center_y = self.height // 2

        # Grid
        for i in range(-10, 11):
            pygame.draw.line(self.screen, (30, 30, 30), 
                           (center_x + i*20, 0), (center_x + i*20, self.height))
            pygame.draw.line(self.screen, (30, 30, 30), 
                           (0, center_y + i*20), (self.width, center_y + i*20))

        # Local player (yeşil)
        pygame.draw.circle(self.screen, (0, 255, 0), (center_x, center_y), 8)
        
        # Enemies (kırmızı)
        for ent in entities:
            if ent.health > 0:
                rx, ry = world_to_radar(local.pos, ent.pos, scale=0.08)
                sx = int(center_x + rx)
                sy = int(center_y - ry)
                if 0 <= sx < self.width and 0 <= sy < self.height:
                    color = (255, 50, 50) if ent.team != 2 else (50, 50, 255)
                    pygame.draw.circle(self.screen, color, (sx, sy), 6)
                    
                    # Health bar
                    health_w = 20
                    health_h = 4
                    pygame.draw.rect(self.screen, (255, 0, 0), 
                                   (sx - health_w//2, sy - 15, health_w, health_h))
                    pygame.draw.rect(self.screen, (0, 255, 0), 
                                   (sx - health_w//2, sy - 15, health_w * (ent.health/100), health_h))

        # Info text
        info = [
            f"Entities: {len([e for e in entities if e.health > 0])}",
            f"Local: ({local.pos[0]:.0f}, {local.pos[1]:.0f})"
        ]
        for i, text in enumerate(info):
            surf = self.font.render(text, True, (255, 255, 255))
            self.screen.blit(surf, (10, 10 + i*25))

        pygame.display.flip()

    def main_loop(self):
        while self.running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
            self.clock.tick(60)